# CLAUDE.md

This file provides guidance to Claude Code (claude.ai/code) when working with code in this repository.

## Project Overview

This is a League of Legends champion statistics and analysis tool that scrapes data from LoLAnalytics and provides champion tier lists, draft assistance, and team composition analysis.

## Architecture

The project follows a modular architecture with clear separation of concerns:

- **main.py**: Entry point and orchestration - handles data loading and executes analysis functions
- **parser.py**: Web scraping module using Selenium WebDriver to extract champion matchup data from LoLAnalytics
- **db.py**: SQLite database layer for storing champion data and matchups with filtering capabilities
- **assistant.py**: Analysis engine providing tier lists, draft recommendations, and team scoring
- **constants.py**: Configuration including current patch, champion lists organized by role

## Core Components

### Data Flow
1. Parser scrapes LoLAnalytics for champion matchup data (winrates, deltas, pick rates, games played)
2. Database stores this data in normalized tables (champions, matchups)
3. Assistant queries database and calculates scores/rankings based on statistical analysis
4. Main orchestrates the process and outputs tier lists by role

### Key Features
- **Tier Lists**: Generate champion rankings by role based on performance metrics
- **Draft Mode**: Suggest optimal picks against enemy team compositions  
- **Team Scoring**: Evaluate team compositions against each other
- **Competitive Draft**: Full draft simulation with pick/ban phases

## Development Commands

### Running the Application
```bash
python main.py
```

### Dependencies
Core dependencies are managed through pip:
- `selenium==4.34.2` - Web scraping
- `lxml==6.0.0` - HTML parsing
- `numpy==2.3.2` - Data processing
- `sqlite3` (built-in) - Database

Install dependencies:
```bash
pip install selenium lxml numpy
```

### Firefox Setup
The parser requires Firefox browser with Selenium WebDriver. Firefox path is hardcoded in `parser.py:15`:
```python
options.binary_location = r'C:\Program Files\Mozilla Firefox\firefox.exe'
```

## Database Schema

### Champions Table
- `id` (PRIMARY KEY)
- `champion` (TEXT) - Champion name

### Matchups Table  
- `champion` (INTEGER) - Foreign key to champions.id
- `enemy` (INTEGER) - Foreign key to champions.id
- `winrate` (REAL) - Win rate percentage
- `delta1` (REAL) - Performance metric 1
- `delta2` (REAL) - Performance metric 2 (primary scoring)
- `pickrate` (REAL) - Pick rate percentage  
- `games` (INTEGER) - Number of games played

## Configuration

### Current Patch
Update `CURRENT_PATCH` in config.py when League patches change.

### Champion Lists
Role-specific champion pools are defined in constants.py:
- `TOP_LIST`, `JUNGLE_LIST`, `MID_LIST`, `ADC_LIST`, `SUPPORT_LIST`
- `CHAMPION_POOL` - Subset for competitive draft analysis
- `CHAMPIONS_LIST` - Complete champion roster

### Filtering Thresholds
- Minimum games for tier list inclusion: 2000 (configurable in assistant.py:9)
- Minimum pick rate for matchup inclusion: 0.5% (db.py:71)
- Minimum games per matchup: 200 (assistant.py filtering)