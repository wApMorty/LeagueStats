# CLAUDE.md

This file provides guidance to Claude Code (claude.ai/code) when working with code in this repository.

## Project Overview

**League Stats Coach** is a comprehensive League of Legends analysis tool that provides real-time draft coaching, champion statistics analysis, and team composition optimization. The application includes both a unified interface (`lol_coach.py`) and a legacy entry point (`main.py`).

## Architecture

The project follows a modular architecture with clear separation of concerns:

### Core Entry Points
- **lol_coach.py**: Main unified application with interactive menu system for all features
- **main.py**: Legacy entry point (deprecated, redirects to lol_coach.py)

### Core Modules (src/)
- **draft_monitor.py**: Real-time draft monitoring and live recommendations during champion select
- **assistant.py**: Analysis engine providing tier lists, draft recommendations, and team scoring
- **parser.py**: Web scraping module using Selenium WebDriver to extract champion matchup data from LoLAnalytics  
- **db.py**: SQLite database layer for storing champion data and matchups with Riot API integration
- **lcu_client.py**: League Client API integration for real-time game state monitoring
- **config.py**: Centralized configuration with PyInstaller support and resource path resolution
- **constants.py**: Champion lists organized by role and competitive pools

## Core Components

### Data Flow
1. Parser scrapes LoLAnalytics for champion matchup data (winrates, deltas, pick rates, games played)
2. Database stores this data in normalized tables (champions, matchups)
3. Assistant queries database and calculates scores/rankings based on statistical analysis
4. Main orchestrates the process and outputs tier lists by role

### Key Features
- **Real-time Draft Coach**: Live recommendations during champion select with League Client integration
- **Automatic Champion Hovering**: Auto-hover recommended champions directly in the League client
- **Champion Pool Management**: Create, edit, and manage custom champion pools with full CRUD operations
- **Team Builder**: Find optimal champion trios and duos with extended champion pools
- **Multi-Role Analysis**: Support for top, support, jungle, mid, adc roles with role-specific data
- **Automatic Data Updates**: Fetch latest champion data from Riot API and parse matchup statistics
- **Standalone Distribution**: Portable executable with PyInstaller for Gaming House deployment
- **Interactive Menu System**: Unified interface for all application features

## Development Commands

### Running the Application
```bash
python lol_coach.py        # Main unified interface
python main.py             # Legacy mode (redirects to lol_coach.py)
```

### Command Line Options
```bash
python lol_coach.py --help              # Show all options
python lol_coach.py --direct-coach      # Skip menu, go directly to draft coach
python lol_coach.py --auto-hover        # Enable automatic champion hovering
python lol_coach.py --verbose           # Enable verbose logging
python lol_coach.py --no-banner         # Skip banner display

# Combined usage examples
python lol_coach.py --direct-coach --auto-hover --verbose  # Full automation mode
```

### Building Distribution
```bash
python build_app.py         # Build standalone executable
python create_package.py    # Create portable ZIP package
```

### Dependencies
Core dependencies are managed through pip:
- `selenium` - Web scraping and browser automation
- `lxml` - HTML parsing for web data extraction  
- `numpy` - Data processing and statistical calculations
- `requests` - HTTP requests for Riot API integration
- `psutil` - Process monitoring for League Client detection
- `sqlite3` (built-in) - Database operations

Install dependencies:
```bash
pip install selenium lxml numpy requests psutil
```

### Firefox Setup
The parser requires Firefox browser with Selenium WebDriver. Firefox path is configured in `config.py` with multiple fallback options:
```python
# Environment variable support
FIREFOX_PATH = os.getenv('FIREFOX_PATH', r'C:\Program Files\Mozilla Firefox\firefox.exe')

# Automatic path detection with fallbacks
paths = [
    os.getenv('FIREFOX_PATH'),
    r'C:\Program Files\Mozilla Firefox\firefox.exe',
    r'C:\Program Files (x86)\Mozilla Firefox\firefox.exe',
]
```

## Database Schema

### Champions Table
- `id` (PRIMARY KEY)
- `champion` (TEXT) - Champion name

### Matchups Table  
- `champion` (INTEGER) - Foreign key to champions.id
- `enemy` (INTEGER) - Foreign key to champions.id
- `winrate` (REAL) - Win rate percentage
- `delta1` (REAL) - Performance metric 1
- `delta2` (REAL) - Performance metric 2 (primary scoring)
- `pickrate` (REAL) - Pick rate percentage  
- `games` (INTEGER) - Number of games played

## Configuration

### Current Patch
Update `CURRENT_PATCH` in config.py when League patches change:
```python
CURRENT_PATCH: str = "15.15"  # Update this for new patches
```

### Champion Lists
Role-specific champion pools are defined in constants.py:
- `TOP_LIST`, `JUNGLE_LIST`, `MID_LIST`, `ADC_LIST`, `SUPPORT_LIST` - Complete role rosters
- `TOP_SOLOQ_POOL` - Focused SoloQ champion pool for faster parsing
- `CHAMPION_POOL` - Subset for competitive draft analysis  
- `CHAMPIONS_LIST` - Complete champion roster (171 champions)

### Filtering Thresholds (config.py)
- `MIN_GAMES_THRESHOLD: int = 2000` - Minimum games for tier list inclusion
- `MIN_GAMES_COMPETITIVE: int = 10000` - Higher threshold for competitive analysis
- `MIN_PICKRATE: float = 0.5` - Minimum pick rate percentage for matchup inclusion
- `MIN_MATCHUP_GAMES: int = 200` - Minimum games per individual matchup

### PyInstaller Configuration
The application supports standalone distribution:
- `DATABASE_PATH` automatically resolves for both development and packaged modes
- Resource path resolution handles `_MEIPASS` and executable directory fallbacks
- Database location: `data/db.db` in development, packaged with executable

## Application Modes

### Menu System (lol_coach.py)
1. **Real-time Draft Coach** - Live recommendations during champion select
   - Option to enable automatic champion hovering
   - Real-time integration with League Client API (LCU)
   - Smart recommendations based on enemy team composition
   - **Enhanced pool selection** with numbered interface and custom pools support
2. **Update Champion Data** - Fetch latest champions from Riot API  
3. **Parse Match Statistics** - Scrape matchup data with custom pool selection
   - **Interactive pool selection** with time estimates
   - Support for custom pools, system pools, or all champions
   - Confirmation dialog with detailed parsing information
4. **Champion Analysis** - Run tier lists and statistical analysis
5. **Optimal Team Builder** - Find best champion combinations
   - **Enhanced pool selection** with suitability indicators (⭐/⚠️)
   - Analysis recommendations based on pool size
   - Support for custom and system pools
6. **Manage Champion Pools** - Complete champion pool management system
   - **Numbered selection interface** for all pool operations
   - Create custom pools with role and tag support
   - Edit existing pools with real-time display and numbered removal
   - Delete, duplicate, and search pools with enhanced UX
   - View detailed pool statistics and information
   - Automatic validation and champion suggestions

### Auto-Hover Feature
The application can automatically hover recommended champions in the League client:
- Uses LCU API endpoints (`/lol-champ-select/v1/session/actions/{actionId}`)
- **Dynamic Updates**: Updates hover when enemy team picks new champions
- **Turn-Based**: Also activates when it's the player's turn to pick  
- **Smart Recommendations**: Hovers the top-rated recommendation based on current enemy picks
- **Team Communication**: Keeps hover updated to show teammates your intended pick
- Can be enabled via menu prompt or `--auto-hover` command line flag
- Includes safety checks to prevent spam and ensure valid actions
- Provides clear feedback: `🎯 [AUTO-HOVER] Hovered {champion} (Enemy pick update)`

### Champion Pool Management
The application includes a comprehensive pool management system:
- **Pool Types**: System pools (built-in) and custom pools (user-created)
- **Metadata**: Each pool has name, description, role, tags, and creator information
- **Storage**: Custom pools saved to `champion_pools.json` with automatic loading
- **Validation**: Real-time champion name validation with auto-suggestions
- **Integration**: Pools available in draft coach for targeted analysis

**Default System Pools:**
- Top SoloQ, Support SoloQ, Competitive
- Extended pools for all roles (Top, Support, Jungle, Mid, ADC)

**Custom Pool Features:**
- Full CRUD operations (Create, Read, Update, Delete)
- Search by name, description, or tags
- Duplication of existing pools
- Role-based filtering and organization

### Legacy Mode (main.py)
Deprecated entry point that redirects to the unified interface. Used for backwards compatibility.